import {
  Armchair,
  Bike,
  Car,
  Clock,
  CreditCard,
  ExternalLink,
  MapPin,
  Navigation,
  Phone,
  ShieldCheck,
  Snowflake,
  Train,
} from 'lucide-react';
import StarRating from '@/components/StarRating';
import { BRANCH, SEATING } from '@/lib/site';

export const metadata = {
  title: 'Aminabad flagship — directions, parking and hours',
  description:
    'How to reach Tunday Kababi at Nazirabad Market, Aminabad, Lucknow: landmarks, parking, seating, opening hours and contact details.',
  alternates: { canonical: '/outlets' },
};

const DAYS = [
  'Monday',
  'Tuesday',
  'Wednesday',
  'Thursday',
  'Friday',
  'Saturday',
  'Sunday',
];

const ROUTES = [
  {
    icon: Train,
    from: 'Charbagh Railway Station',
    detail:
      'About 3 km. Auto to Aminabad Chauraha takes 12–15 minutes, then a 300 m walk into Nazirabad Market.',
  },
  {
    icon: Navigation,
    from: 'Hazratganj',
    detail:
      'About 2 km along Ashok Marg. Ask for Aminabad Ghanta Ghar — the market lane starts just behind it.',
  },
  {
    icon: Car,
    from: 'Chaudhary Charan Singh Airport',
    detail:
      'About 13 km, roughly 35 minutes off-peak. Come via Kanpur Road and Naka Hindola.',
  },
  {
    icon: Bike,
    from: 'Inside Aminabad',
    detail:
      'From Prince Market, take the second lane on the left. The tawa is visible from the street once you are in.',
  },
];

const FACILITIES = [
  { icon: Snowflake, label: 'Air-conditioned family floor' },
  { icon: Armchair, label: '42 covers upstairs' },
  { icon: ShieldCheck, label: 'Halal certified kitchen' },
  { icon: CreditCard, label: 'Cash, UPI and cards' },
];

export default function OutletsPage() {
  return (
    <div className="shell py-12 sm:py-16">
      <header className="max-w-2xl">
        <p className="text-sm font-medium text-accent">{BRANCH.label}</p>
        <h1 className="mt-3 font-display text-4xl text-fg sm:text-5xl">
          Nazirabad Market, Aminabad
        </h1>
        <p className="mt-4 text-base leading-relaxed text-muted">
          One address, no branches under this name. If you are coming for the first time,
          read the parking note below — the lane itself is walking-only in the evening.
        </p>
        <StarRating
          value={BRANCH.rating}
          reviews={BRANCH.reviewCount}
          size={16}
          className="mt-5"
        />
      </header>

      {/* Map mockup */}
      <section className="mt-10">
        <div className="card-surface relative overflow-hidden">
          <svg
            viewBox="0 0 800 400"
            role="img"
            aria-label="Simplified map of Nazirabad Market, Aminabad, showing Tunday Kababi and nearby parking"
            className="h-[280px] w-full sm:h-[380px]"
          >
            <rect width="800" height="400" className="fill-raised" />

            {/* Block shapes */}
            <g className="fill-card">
              <rect x="40" y="40" width="200" height="120" rx="6" />
              <rect x="300" y="40" width="190" height="90" rx="6" />
              <rect x="560" y="40" width="200" height="130" rx="6" />
              <rect x="40" y="250" width="180" height="110" rx="6" />
              <rect x="300" y="230" width="210" height="130" rx="6" />
              <rect x="590" y="240" width="170" height="120" rx="6" />
            </g>

            {/* Roads */}
            <g className="stroke-line" strokeWidth="26" strokeLinecap="round">
              <line x1="20" y1="200" x2="780" y2="200" />
              <line x1="265" y1="20" x2="265" y2="380" />
              <line x1="540" y1="20" x2="540" y2="380" />
            </g>
            <g
              className="stroke-accent"
              strokeWidth="2"
              strokeDasharray="10 12"
              opacity="0.45"
            >
              <line x1="20" y1="200" x2="780" y2="200" />
            </g>

            {/* Labels */}
            <g className="fill-muted" fontSize="13" fontFamily="inherit">
              <text x="60" y="95">Prince Market</text>
              <text x="60" y="113" fontSize="11">Paid car parking · 250 m</text>
              <text x="320" y="80">Aminabad Ghanta Ghar</text>
              <text x="580" y="90">Aminabad Inter College</text>
              <text x="580" y="108" fontSize="11">Ground parking · 400 m</text>
              <text x="60" y="305">Two-wheeler row</text>
              <text x="610" y="300">Mohan Market</text>
              <text x="300" y="192" fontSize="11">Nazirabad Market Road</text>
            </g>

            {/* Marker */}
            <g transform="translate(360, 230)">
              <circle cx="24" cy="24" r="30" className="fill-accent" opacity="0.18" />
              <circle cx="24" cy="24" r="10" className="fill-accent" />
              <circle cx="24" cy="24" r="4" className="fill-card" />
              <text x="46" y="20" className="fill-fg" fontSize="15" fontWeight="700">
                Tunday Kababi
              </text>
              <text x="46" y="38" className="fill-muted" fontSize="12">
                Nazirabad Market · open till 11:30 PM
              </text>
            </g>
          </svg>

          <div className="flex flex-wrap items-center justify-between gap-3 border-t border-line px-5 py-4">
            <p className="text-xs text-muted">
              Sketch map, not to scale. Use Google Maps for live navigation.
            </p>
            <a
              href={BRANCH.mapsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="btn-solid"
            >
              Open in Google Maps <ExternalLink size={14} />
            </a>
          </div>
        </div>
      </section>

      {/* Address, hours, contact */}
      <section className="mt-12 grid gap-6 lg:grid-cols-3">
        <div className="card-surface p-6">
          <MapPin size={18} className="text-accent" />
          <h2 className="mt-3 font-display text-xl text-fg">Address</h2>
          <address className="mt-3 not-italic text-sm leading-relaxed text-muted">
            {BRANCH.street}
            <br />
            {BRANCH.city}, {BRANCH.state} {BRANCH.postalCode}
            <br />
            India
          </address>
          <a
            href={BRANCH.mapsUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-4 inline-block text-sm text-accent hover:underline"
          >
            Get directions
          </a>
        </div>

        <div className="card-surface p-6">
          <Clock size={18} className="text-accent" />
          <h2 className="mt-3 font-display text-xl text-fg">Opening hours</h2>
          <ul className="mt-3 flex flex-col gap-1.5 text-sm">
            {DAYS.map((day) => (
              <li key={day} className="flex justify-between text-muted">
                <span>{day}</span>
                <span className="text-fg">11:00 AM – 11:30 PM</span>
              </li>
            ))}
          </ul>
          <p className="mt-4 text-xs text-muted">
            Last orders at 11:15 PM. Nihari is served from opening until it runs out,
            usually around 1 PM.
          </p>
        </div>

        <div className="card-surface p-6">
          <Phone size={18} className="text-accent" />
          <h2 className="mt-3 font-display text-xl text-fg">Contact</h2>
          <ul className="mt-3 flex flex-col gap-2 text-sm text-muted">
            <li>
              <a href={`tel:${BRANCH.phoneDial}`} className="hover:text-accent">
                {BRANCH.phoneDisplay}
              </a>
            </li>
            <li>
              <a
                href={`https://wa.me/${BRANCH.whatsapp}`}
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-accent"
              >
                WhatsApp orders
              </a>
            </li>
            <li>
              <a href={`mailto:${BRANCH.email}`} className="break-all hover:text-accent">
                {BRANCH.email}
              </a>
            </li>
          </ul>
          <p className="mt-4 text-xs text-muted">
            We do not take table reservations. Walk in, or order ahead for pickup.
          </p>
        </div>
      </section>

      {/* Seating and parking */}
      <section className="mt-16">
        <h2 className="font-display text-3xl text-fg">Seating, takeaway and parking</h2>
        <div className="mt-8 grid gap-6 lg:grid-cols-3">
          {SEATING.map((item) => (
            <article key={item.title} className="card-surface p-6">
              <h3 className="text-base font-semibold text-fg">{item.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted">{item.detail}</p>
            </article>
          ))}
        </div>

        <ul className="mt-8 flex flex-wrap gap-3">
          {FACILITIES.map((facility) => (
            <li key={facility.label} className="chip">
              <facility.icon size={13} className="text-accent" />
              {facility.label}
            </li>
          ))}
        </ul>
      </section>

      {/* Getting here */}
      <section className="mt-16">
        <h2 className="font-display text-3xl text-fg">Getting here</h2>
        <div className="mt-8 grid gap-6 sm:grid-cols-2">
          {ROUTES.map((route) => (
            <article key={route.from} className="flex gap-4 border-t border-line pt-5">
              <route.icon size={18} className="mt-0.5 shrink-0 text-accent" />
              <div>
                <h3 className="text-base font-semibold text-fg">{route.from}</h3>
                <p className="mt-1.5 text-sm leading-relaxed text-muted">
                  {route.detail}
                </p>
              </div>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
}
