'use client';

import { useMemo, useState } from 'react';
import { CheckCircle2, Users } from 'lucide-react';
import { CATERING_PACKAGES } from '@/lib/menu';
import { BRANCH, TAX_RATE, currency } from '@/lib/site';

const EVENT_TYPES = [
  'Wedding or nikah',
  'Walima or reception',
  'Corporate event',
  'Birthday or anniversary',
  'Iftar or community dawat',
  'Something else',
];

const EMPTY = {
  name: '',
  phone: '',
  email: '',
  eventDate: '',
  guests: '',
  eventType: '',
  packageId: '',
  venue: '',
  notes: '',
};

function todayISO() {
  const now = new Date();
  const offsetMs = now.getTimezoneOffset() * 60000;
  return new Date(now.getTime() - offsetMs).toISOString().slice(0, 10);
}

export default function CateringPage() {
  const [form, setForm] = useState(EMPTY);
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(null);

  const minDate = todayISO();
  const selectedPackage = CATERING_PACKAGES.find((entry) => entry.id === form.packageId);

  const estimate = useMemo(() => {
    const guests = Number(form.guests);
    if (!selectedPackage || !guests || guests < 1) return null;
    const food = selectedPackage.perHead * guests;
    const gst = Math.round(food * TAX_RATE);
    return { food, gst, total: food + gst };
  }, [selectedPackage, form.guests]);

  const update = (field) => (event) => {
    const { value } = event.target;
    setForm((current) => ({ ...current, [field]: value }));
    setErrors((current) => {
      if (!current[field]) return current;
      const next = { ...current };
      delete next[field];
      return next;
    });
  };

  const validate = () => {
    const next = {};

    if (form.name.trim().length < 2) {
      next.name = 'Tell us who to ask for when we call back.';
    }

    if (!/^(\+91[\s-]?)?[6-9]\d{9}$/.test(form.phone.replace(/\s|-/g, ''))) {
      next.phone = 'Enter a 10-digit Indian mobile number, for example 98390 12345.';
    }

    if (form.email.trim() !== '' && !/^\S+@\S+\.\S{2,}$/.test(form.email.trim())) {
      next.email = 'That email address does not look complete.';
    }

    if (!form.eventDate) {
      next.eventDate = 'Pick the date of the event.';
    } else if (form.eventDate < minDate) {
      next.eventDate = 'Choose today or a date after it.';
    }

    const guests = Number(form.guests);
    if (!form.guests || Number.isNaN(guests)) {
      next.guests = 'Enter how many people you are expecting.';
    } else if (guests < 40) {
      next.guests = 'Catering starts at 40 guests. For smaller groups, order from the menu.';
    } else if (guests > 2000) {
      next.guests = 'For more than 2,000 guests, call the counter so we can plan it properly.';
    }

    if (!form.eventType) {
      next.eventType = 'Choose the kind of event.';
    }

    if (!form.packageId) {
      next.packageId = 'Pick a menu to start from. We can change it later.';
    } else if (guests && guests < selectedPackage?.minGuests) {
      next.packageId = `${selectedPackage.name} needs at least ${selectedPackage.minGuests} guests.`;
    }

    if (form.venue.trim().length < 3) {
      next.venue = 'Where is the event? Area name is enough.';
    }

    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!validate()) {
      const firstError = document.querySelector('[data-error="true"]');
      if (firstError) firstError.scrollIntoView({ block: 'center', behavior: 'smooth' });
      return;
    }
    setSubmitted({ ...form, estimate, packageName: selectedPackage.name });
  };

  const whatsappLink = () => {
    if (!submitted) return '#';
    const message = [
      'Catering enquiry — Tunday Kababi, Aminabad',
      '',
      `Name: ${submitted.name}`,
      `Phone: ${submitted.phone}`,
      submitted.email ? `Email: ${submitted.email}` : '',
      `Event: ${submitted.eventType}`,
      `Date: ${submitted.eventDate}`,
      `Guests: ${submitted.guests}`,
      `Menu: ${submitted.packageName}`,
      `Venue: ${submitted.venue}`,
      submitted.estimate
        ? `Indicative total: ${currency(submitted.estimate.total)} including GST`
        : '',
      submitted.notes ? `Notes: ${submitted.notes}` : '',
    ]
      .filter(Boolean)
      .join('\n');

    return `https://wa.me/${BRANCH.whatsapp}?text=${encodeURIComponent(message)}`;
  };

  if (submitted) {
    return (
      <div className="shell py-20">
        <div className="card-surface mx-auto max-w-2xl p-8 text-center sm:p-12">
          <CheckCircle2 size={34} className="mx-auto text-accent" strokeWidth={1.5} />
          <h1 className="mt-4 font-display text-3xl text-fg">
            Enquiry noted, {submitted.name.split(' ')[0]}
          </h1>
          <p className="mx-auto mt-3 max-w-md text-sm leading-relaxed text-muted">
            We have your request for {submitted.guests} guests on {submitted.eventDate} —{' '}
            {submitted.packageName}. Someone from the Aminabad kitchen calls back within
            one working day to fix the menu and the advance.
          </p>

          {submitted.estimate ? (
            <dl className="mx-auto mt-8 flex max-w-sm flex-col gap-2 text-left text-sm">
              <div className="flex justify-between text-muted">
                <dt>Food, {submitted.guests} guests</dt>
                <dd className="text-fg">{currency(submitted.estimate.food)}</dd>
              </div>
              <div className="flex justify-between text-muted">
                <dt>GST at 5%</dt>
                <dd className="text-fg">{currency(submitted.estimate.gst)}</dd>
              </div>
              <div className="my-1 rule-gold" />
              <div className="flex justify-between font-semibold">
                <dt className="text-fg">Indicative total</dt>
                <dd className="text-accent">{currency(submitted.estimate.total)}</dd>
              </div>
            </dl>
          ) : null}

          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <a
              href={whatsappLink()}
              target="_blank"
              rel="noopener noreferrer"
              className="btn-solid"
            >
              Send the same details on WhatsApp
            </a>
            <button
              type="button"
              onClick={() => {
                setForm(EMPTY);
                setSubmitted(null);
              }}
              className="btn-ghost"
            >
              Start another enquiry
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="shell py-12 sm:py-16">
      <header className="max-w-2xl">
        <h1 className="font-display text-4xl text-fg sm:text-5xl">
          Catering and large orders
        </h1>
        <p className="mt-4 text-base leading-relaxed text-muted">
          We cook for weddings, walimas and office dawats across Lucknow, with a live
          kebab counter if the venue allows an open flame. Minimum forty guests, and we
          ask for a week&apos;s notice on anything above two hundred.
        </p>
      </header>

      <section className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
        {CATERING_PACKAGES.map((entry) => (
          <article key={entry.id} className="card-surface p-5">
            <h2 className="font-display text-lg text-fg">{entry.name}</h2>
            <p className="mt-2 text-2xl font-semibold text-accent">
              {currency(entry.perHead)}
              <span className="ml-1 text-xs font-normal text-muted">per guest</span>
            </p>
            <p className="mt-3 text-sm leading-relaxed text-muted">{entry.includes}</p>
            <p className="mt-4 inline-flex items-center gap-1.5 text-xs text-muted">
              <Users size={13} className="text-accent" /> From {entry.minGuests} guests
            </p>
          </article>
        ))}
      </section>

      <form onSubmit={handleSubmit} noValidate className="mt-16 grid gap-10 lg:grid-cols-[1.4fr_1fr]">
        <div className="card-surface p-6 sm:p-8">
          <h2 className="font-display text-2xl text-fg">Tell us about the event</h2>
          <p className="mt-2 text-sm text-muted">
            Everything except email and notes is needed before we can quote.
          </p>

          <div className="mt-8 grid gap-5 sm:grid-cols-2">
            <Field
              id="name"
              label="Your name"
              error={errors.name}
              value={form.name}
              onChange={update('name')}
              placeholder="Ayesha Siddiqui"
              autoComplete="name"
            />
            <Field
              id="phone"
              label="Mobile number"
              error={errors.phone}
              value={form.phone}
              onChange={update('phone')}
              placeholder="98390 12345"
              inputMode="tel"
              autoComplete="tel"
            />
            <Field
              id="email"
              label="Email (optional)"
              error={errors.email}
              value={form.email}
              onChange={update('email')}
              placeholder="you@example.com"
              type="email"
              autoComplete="email"
            />
            <Field
              id="eventDate"
              label="Event date"
              error={errors.eventDate}
              value={form.eventDate}
              onChange={update('eventDate')}
              type="date"
              min={minDate}
            />
            <Field
              id="guests"
              label="Number of guests"
              error={errors.guests}
              value={form.guests}
              onChange={update('guests')}
              placeholder="150"
              type="number"
              min={40}
              max={2000}
            />

            <div data-error={Boolean(errors.eventType)}>
              <label htmlFor="eventType" className="mb-1.5 block text-sm font-medium text-fg">
                Kind of event
              </label>
              <select
                id="eventType"
                value={form.eventType}
                onChange={update('eventType')}
                className="field"
                aria-invalid={Boolean(errors.eventType)}
              >
                <option value="">Choose one</option>
                {EVENT_TYPES.map((type) => (
                  <option key={type} value={type}>
                    {type}
                  </option>
                ))}
              </select>
              {errors.eventType ? (
                <p className="mt-1.5 text-xs text-royal">{errors.eventType}</p>
              ) : null}
            </div>

            <div className="sm:col-span-2">
              <Field
                id="venue"
                label="Venue or area"
                error={errors.venue}
                value={form.venue}
                onChange={update('venue')}
                placeholder="Lawn behind Sahara Ganj, Hazratganj"
              />
            </div>

            <fieldset className="sm:col-span-2" data-error={Boolean(errors.packageId)}>
              <legend className="mb-2 text-sm font-medium text-fg">
                Menu to start from
              </legend>
              <div className="grid gap-2 sm:grid-cols-2">
                {CATERING_PACKAGES.map((entry) => (
                  <label
                    key={entry.id}
                    className={`flex cursor-pointer items-start gap-3 rounded-xl border p-3 transition ${
                      form.packageId === entry.id
                        ? 'border-accent bg-accent/10'
                        : 'border-line hover:border-accent/60'
                    }`}
                  >
                    <input
                      type="radio"
                      name="packageId"
                      value={entry.id}
                      checked={form.packageId === entry.id}
                      onChange={update('packageId')}
                      className="mt-1 accent-current"
                    />
                    <span>
                      <span className="block text-sm font-semibold text-fg">
                        {entry.name}
                      </span>
                      <span className="block text-xs text-muted">
                        {currency(entry.perHead)} per guest · from {entry.minGuests}{' '}
                        guests
                      </span>
                    </span>
                  </label>
                ))}
              </div>
              {errors.packageId ? (
                <p className="mt-1.5 text-xs text-royal">{errors.packageId}</p>
              ) : null}
            </fieldset>

            <div className="sm:col-span-2">
              <label htmlFor="notes" className="mb-1.5 block text-sm font-medium text-fg">
                Anything else (optional)
              </label>
              <textarea
                id="notes"
                value={form.notes}
                onChange={update('notes')}
                rows={4}
                className="field resize-y"
                placeholder="Half the guests are vegetarian, we need service staff, the venue does not allow open flame…"
              />
            </div>
          </div>

          <button type="submit" className="btn-solid mt-8 w-full sm:w-auto">
            Send enquiry
          </button>
        </div>

        <aside className="lg:sticky lg:top-24 lg:self-start">
          <div className="card-surface p-6">
            <h2 className="font-display text-xl text-fg">Running estimate</h2>
            {estimate ? (
              <dl className="mt-5 flex flex-col gap-2 text-sm">
                <div className="flex justify-between text-muted">
                  <dt>
                    {selectedPackage.name}, {form.guests} guests
                  </dt>
                  <dd className="text-fg">{currency(estimate.food)}</dd>
                </div>
                <div className="flex justify-between text-muted">
                  <dt>GST at 5%</dt>
                  <dd className="text-fg">{currency(estimate.gst)}</dd>
                </div>
                <div className="my-1 rule-gold" />
                <div className="flex justify-between text-base font-semibold">
                  <dt className="text-fg">Indicative total</dt>
                  <dd className="text-accent">{currency(estimate.total)}</dd>
                </div>
              </dl>
            ) : (
              <p className="mt-4 text-sm leading-relaxed text-muted">
                Choose a menu and enter the guest count to see a figure here. It updates
                as you type.
              </p>
            )}

            <p className="mt-6 text-xs leading-relaxed text-muted">
              Indicative only. Final quotes account for travel, staff, live counters and
              any dish swaps. We take 30% as advance and the balance on the event day.
            </p>

            <div className="mt-6 border-t border-line pt-5 text-sm">
              <p className="font-semibold text-fg">Prefer to talk it through?</p>
              <a
                href={`tel:${BRANCH.phoneDial}`}
                className="mt-1 inline-block text-accent hover:underline"
              >
                {BRANCH.phoneDisplay}
              </a>
              <p className="mt-1 text-xs text-muted">{BRANCH.hours}</p>
            </div>
          </div>
        </aside>
      </form>
    </div>
  );
}

function Field({ id, label, error, ...props }) {
  return (
    <div data-error={Boolean(error)}>
      <label htmlFor={id} className="mb-1.5 block text-sm font-medium text-fg">
        {label}
      </label>
      <input
        id={id}
        name={id}
        className="field"
        aria-invalid={Boolean(error)}
        aria-describedby={error ? `${id}-error` : undefined}
        {...props}
      />
      {error ? (
        <p id={`${id}-error`} className="mt-1.5 text-xs text-royal">
          {error}
        </p>
      ) : null}
    </div>
  );
}
