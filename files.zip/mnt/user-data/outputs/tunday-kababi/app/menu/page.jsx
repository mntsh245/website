'use client';

import { useMemo, useState } from 'react';
import { Search, SlidersHorizontal, X } from 'lucide-react';
import DishCard from '@/components/DishCard';
import MenuReel from '@/components/MenuReel';
import StarRating from '@/components/StarRating';
import { CATEGORIES, DIETS, MENU } from '@/lib/menu';
import { BRANCH } from '@/lib/site';
import { useCart } from '@/app/providers';

export default function MenuPage() {
  const { totals, openCart } = useCart();
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState('All');
  const [diets, setDiets] = useState([]);

  const toggleDiet = (diet) => {
    setDiets((current) =>
      current.includes(diet)
        ? current.filter((entry) => entry !== diet)
        : [...current, diet]
    );
  };

  const resetFilters = () => {
    setQuery('');
    setCategory('All');
    setDiets([]);
  };

  const results = useMemo(() => {
    const needle = query.trim().toLowerCase();

    return MENU.filter((item) => {
      const inCategory = category === 'All' || item.category === category;
      const inDiet = diets.length === 0 || diets.includes(item.diet);
      const inSearch =
        needle === '' ||
        item.name.toLowerCase().includes(needle) ||
        item.local.includes(query.trim()) ||
        item.category.toLowerCase().includes(needle) ||
        item.diet.toLowerCase().includes(needle) ||
        item.story.toLowerCase().includes(needle);

      return inCategory && inDiet && inSearch;
    });
  }, [query, category, diets]);

  const filtersActive = query.trim() !== '' || category !== 'All' || diets.length > 0;

  return (
    <div className="shell py-12 sm:py-16">
      <header className="max-w-2xl">
        <h1 className="font-display text-4xl text-fg sm:text-5xl">The full menu</h1>
        <p className="mt-4 text-base leading-relaxed text-muted">
          Every dish is cooked to order at the Nazirabad counter. Choose half or full,
          build your order, and send it to us on WhatsApp — we confirm before the kebabs
          go on the tawa.
        </p>
        <StarRating
          value={BRANCH.rating}
          reviews={BRANCH.reviewCount}
          size={16}
          className="mt-5"
        />
      </header>

      <div className="-mx-5 mt-10 sm:-mx-8">
        <MenuReel heading="Start with the signatures" />
      </div>

      {/* Controls */}
      <div className="sticky top-[72px] z-30 -mx-5 mt-12 border-y border-line bg-bg/95 px-5 py-4 backdrop-blur sm:-mx-8 sm:px-8">
        <div className="relative">
          <Search
            size={17}
            className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-muted"
          />
          <input
            type="search"
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Search galouti, nihari, paratha, phirni…"
            aria-label="Search the menu"
            className="field pl-11"
          />
        </div>

        <div
          className="mt-3 flex gap-2 overflow-x-auto pb-1"
          role="tablist"
          aria-label="Menu categories"
        >
          {CATEGORIES.map((entry) => (
            <button
              key={entry}
              type="button"
              role="tab"
              aria-selected={category === entry}
              onClick={() => setCategory(entry)}
              className={`chip shrink-0 ${category === entry ? 'chip-on' : ''}`}
            >
              {entry}
            </button>
          ))}
        </div>

        <div className="mt-2 flex flex-wrap items-center gap-2">
          <span className="inline-flex items-center gap-1.5 text-xs font-medium text-muted">
            <SlidersHorizontal size={13} /> Dietary
          </span>
          {DIETS.map((diet) => (
            <button
              key={diet}
              type="button"
              onClick={() => toggleDiet(diet)}
              aria-pressed={diets.includes(diet)}
              className={`chip ${diets.includes(diet) ? 'chip-on' : ''}`}
            >
              {diet}
            </button>
          ))}

          {filtersActive ? (
            <button
              type="button"
              onClick={resetFilters}
              className="chip hover:border-royal hover:text-royal"
            >
              <X size={12} /> Clear
            </button>
          ) : null}

          {totals.count > 0 ? (
            <button
              type="button"
              onClick={openCart}
              className="ml-auto text-xs font-semibold text-accent hover:underline"
            >
              Review order ({totals.count})
            </button>
          ) : null}
        </div>
      </div>

      <p className="mt-6 text-sm text-muted">
        {results.length} {results.length === 1 ? 'dish' : 'dishes'}
        {category !== 'All' ? ` in ${category}` : ''}
        {diets.length > 0 ? ` · ${diets.join(', ')}` : ''}
      </p>

      {results.length === 0 ? (
        <div className="card-surface mt-6 p-10 text-center">
          <p className="font-display text-xl text-fg">Nothing matches that yet</p>
          <p className="mx-auto mt-2 max-w-md text-sm text-muted">
            Try a shorter word — &ldquo;kebab&rdquo;, &ldquo;paratha&rdquo; or
            &ldquo;biryani&rdquo; — or clear the filters to see the whole menu.
          </p>
          <button type="button" onClick={resetFilters} className="btn-solid mt-5">
            Clear filters
          </button>
        </div>
      ) : (
        <div className="mt-6 grid gap-6 sm:grid-cols-2 xl:grid-cols-3">
          {results.map((item) => (
            <DishCard key={item.id} item={item} />
          ))}
        </div>
      )}

      <p className="mt-12 text-xs leading-relaxed text-muted">
        All prices in rupees and inclusive of nothing but the food — 5% GST and packaging
        are added at checkout. Vegetarian dishes are cooked in a separate station with
        separate utensils. Kitchen closes for new orders at 11:15 PM.
      </p>
    </div>
  );
}
