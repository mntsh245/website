import Link from 'next/link';
import { ArrowRight, Clock, MapPin, Quote } from 'lucide-react';
import StarRating from '@/components/StarRating';
import ScrollReveal from '@/components/ScrollReveal';
import FloatingGarnish from '@/components/FloatingGarnish';
import CircleDish from '@/components/CircleDish';
import MenuIntro from '@/components/MenuIntro';
import ScrollFeast from '@/components/ScrollFeast';
import { REVIEWS, SUPERSTARS } from '@/lib/menu';
import { BRANCH, SEATING } from '@/lib/site';

const INGREDIENTS = [
  '160 Secret Spices',
  'Raw Papaya Tenderiser',
  'Stone-Ground Mince',
  'Saffron & Kewra',
  'Charcoal-Fed Tawa',
  'Farm Mutton, Daily',
  'Mustard Oil',
  'Kashmiri Chilli',
];

const HIGHLIGHTS = [
  {
    tag: 'This week',
    title: 'Nihari, before it runs out',
    text: 'Simmered from midnight, served only till around 1 PM. Once the daily batch is gone, it is gone — no second round.',
    href: '/menu',
    cta: 'See today\u2019s menu',
  },
  {
    tag: 'For your event',
    title: 'Live kebab counter for 40+ guests',
    text: 'Galouti and seekh made to order at your venue, ulte tawe ka paratha off a live tawa. Built for weddings and office dawats.',
    href: '/catering',
    cta: 'Plan your catering',
  },
  {
    tag: 'First visit?',
    title: 'AC family floor, upstairs',
    text: 'Takeaway counter runs downstairs; a quieter, air-conditioned family floor sits above it. No reservations — just walk in.',
    href: '/outlets',
    cta: 'Directions & parking',
  },
];

export default function HomePage() {
  return (
    <>
      <MenuIntro />

      {/* ---------------- Hero ---------------- */}
      <section className="relative overflow-hidden border-b border-line">
        <div
          aria-hidden="true"
          className="pointer-events-none absolute inset-0 bg-jaali [background-size:26px_26px] opacity-40"
        />
        <div
          aria-hidden="true"
          className="pointer-events-none absolute -top-40 left-1/2 h-[560px] w-[560px] -translate-x-1/2 rounded-full bg-accent/10 blur-3xl"
        />

        <div className="shell relative grid gap-14 py-20 sm:py-28 lg:grid-cols-[1.15fr_1fr] lg:items-center">
          <div>
            <p className="section-kicker">A legendary, authentic kebab house</p>

            <h1 className="mt-3 font-display text-5xl leading-[1.04] text-fg sm:text-6xl lg:text-[4.6rem]">
              The kebab that
              <br />
              doesn&apos;t need teeth.
            </h1>

            <p className="mt-6 max-w-lg text-base leading-relaxed text-muted">
              One hundred and sixty spices, mince worked on stone until it gives way, on
              an iron tawa that has not been off the heat since 1905. Nazirabad Market,
              Aminabad — same lane, four generations.
            </p>

            <div className="mt-7">
              <StarRating value={BRANCH.rating} reviews={BRANCH.reviewCount} size={17} />
            </div>

            <div className="mt-9 flex flex-wrap gap-3">
              <Link href="/menu" className="btn-solid">
                See the menu and order <ArrowRight size={15} />
              </Link>
              <Link href="/outlets" className="btn-ghost">
                Directions and parking
              </Link>
            </div>

            <dl className="mt-12 grid max-w-md grid-cols-2 gap-6 border-t border-line pt-8 text-sm">
              <div>
                <dt className="text-muted">Open daily</dt>
                <dd className="mt-1 font-display text-lg text-fg">11 AM – 11:30 PM</dd>
              </div>
              <div>
                <dt className="text-muted">Since</dt>
                <dd className="mt-1 font-display text-lg text-fg">1905</dd>
              </div>
            </dl>
          </div>

          <div className="relative flex justify-center py-6 lg:justify-end lg:py-0">
            <FloatingGarnish variant="hero" />
            <CircleDish item={SUPERSTARS[0]} size="lg" />
          </div>
        </div>
      </section>

      {/* ---------------- Scroll-driven plate assembly ---------------- */}
      <ScrollFeast />

      {/* ---------------- Our Story ---------------- */}
      <section className="shell py-24 sm:py-28">
        <div className="grid items-center gap-14 lg:grid-cols-2">
          <ScrollReveal className="relative order-2 flex justify-center lg:order-1">
            <FloatingGarnish variant="dish" />
            <CircleDish item={SUPERSTARS[1]} size="md" />
          </ScrollReveal>

          <ScrollReveal delay={120} className="order-1 lg:order-2">
            <p className="section-kicker">Our story</p>
            <h2 className="mt-3 font-display text-4xl leading-tight text-fg sm:text-5xl">
              Four generations,
              <br />
              one recipe, no shortcuts
            </h2>
            <p className="mt-6 max-w-md text-base leading-relaxed text-muted">
              In 1905, Haji Murad Ali — known as Tunday for the use of only one arm — was
              asked for a kebab a toothless Nawab could still enjoy. He answered with a
              blend of 160 spices, fixed once and never sold. It is ground the same way
              today, by one family member at a time, on the same lane in Aminabad.
            </p>
            <ul className="mt-8 flex flex-col gap-4 border-l-2 border-accent/40 pl-5 text-sm">
              <li>
                <span className="font-display text-fg">1905 — </span>
                <span className="text-muted">the recipe is invented for a Nawab.</span>
              </li>
              <li>
                <span className="font-display text-fg">1960s — </span>
                <span className="text-muted">the shop settles into Nazirabad Market.</span>
              </li>
              <li>
                <span className="font-display text-fg">Today — </span>
                <span className="text-muted">
                  fourth generation on the tawa, same 160-spice blend.
                </span>
              </li>
            </ul>
          </ScrollReveal>
        </div>
      </section>

      {/* ---------------- Our Menu — circular showcase ---------------- */}
      <section className="border-y border-line bg-card/50 py-24 sm:py-28">
        <div className="shell">
          <ScrollReveal className="mx-auto max-w-xl text-center">
            <p className="section-kicker">Discover</p>
            <h2 className="mt-3 font-display text-4xl text-fg sm:text-5xl">Our menu</h2>
            <p className="mt-4 text-base leading-relaxed text-muted">
              Six dishes carry the name. Everything else on the card exists to go
              alongside them.
            </p>
          </ScrollReveal>

          <div className="mt-16 grid grid-cols-2 gap-x-6 gap-y-16 sm:grid-cols-3 lg:grid-cols-6">
            {SUPERSTARS.map((dish, index) => (
              <ScrollReveal
                key={dish.id}
                delay={index * 90}
                className="flex flex-col items-center text-center"
              >
                <div className="relative">
                  <FloatingGarnish variant="dish" />
                  <CircleDish item={dish} size="sm" />
                </div>
                <p className="mt-5 font-display text-base text-fg">
                  {dish.name.replace('Legendary ', '')}
                </p>
                <p className="mt-1 text-xs text-accent">₹{dish.full}</p>
              </ScrollReveal>
            ))}
          </div>

          <ScrollReveal className="mt-14 text-center">
            <Link href="/menu" className="btn-solid">
              View the full menu <ArrowRight size={15} />
            </Link>
          </ScrollReveal>
        </div>
      </section>

      {/* ---------------- Ingredients marquee ---------------- */}
      <section className="overflow-hidden py-14">
        <ScrollReveal className="shell mx-auto max-w-xl text-center">
          <p className="section-kicker">What goes in</p>
          <h2 className="mt-3 font-display text-3xl text-fg sm:text-4xl">
            The best ingredients, nothing hidden
          </h2>
        </ScrollReveal>

        <div className="relative mt-10 overflow-hidden">
          <div
            aria-hidden="true"
            className="pointer-events-none absolute inset-y-0 left-0 z-10 w-16 bg-gradient-to-r from-bg to-transparent sm:w-32"
          />
          <div
            aria-hidden="true"
            className="pointer-events-none absolute inset-y-0 right-0 z-10 w-16 bg-gradient-to-l from-bg to-transparent sm:w-32"
          />
          <div className="marquee-track flex w-max gap-4">
            {[...INGREDIENTS, ...INGREDIENTS].map((label, index) => (
              <span
                key={`${label}-${index}`}
                className="chip whitespace-nowrap px-4 py-2 text-sm"
              >
                {label}
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* ---------------- Highlights (specials / catering / visiting) ---------------- */}
      <section className="shell py-24 sm:py-28">
        <ScrollReveal className="mx-auto max-w-xl text-center">
          <p className="section-kicker">Right now</p>
          <h2 className="mt-3 font-display text-4xl text-fg sm:text-5xl">
            What&apos;s worth knowing
          </h2>
        </ScrollReveal>

        <div className="mt-14 grid gap-6 md:grid-cols-3">
          {HIGHLIGHTS.map((item, index) => (
            <ScrollReveal key={item.title} delay={index * 100}>
              <article className="card-surface flex h-full flex-col p-7">
                <span className="text-xs font-semibold uppercase tracking-wide text-accent">
                  {item.tag}
                </span>
                <h3 className="mt-3 font-display text-xl text-fg">{item.title}</h3>
                <p className="mt-3 flex-1 text-sm leading-relaxed text-muted">
                  {item.text}
                </p>
                <Link
                  href={item.href}
                  className="mt-5 inline-flex items-center gap-1.5 text-sm font-semibold text-accent hover:underline"
                >
                  {item.cta} <ArrowRight size={14} />
                </Link>
              </article>
            </ScrollReveal>
          ))}
        </div>
      </section>

      {/* ---------------- Reviews ---------------- */}
      <section className="border-y border-line bg-card/50 py-24 sm:py-28">
        <div className="shell">
          <ScrollReveal className="flex flex-wrap items-end justify-between gap-6">
            <div className="max-w-xl">
              <p className="section-kicker">Word of mouth</p>
              <h2 className="mt-3 font-display text-4xl text-fg sm:text-5xl">
                What people write afterwards
              </h2>
            </div>
            <StarRating value={BRANCH.rating} reviews={BRANCH.reviewCount} size={18} />
          </ScrollReveal>

          <div className="mt-12 grid gap-6 md:grid-cols-2">
            {REVIEWS.map((review, index) => (
              <ScrollReveal key={review.name} delay={index * 90}>
                <figure className="card-surface h-full p-6">
                  <Quote size={18} className="text-accent" />
                  <blockquote className="mt-3 text-sm leading-relaxed text-fg/90">
                    {review.text}
                  </blockquote>
                  <figcaption className="mt-5 flex items-center justify-between gap-4 border-t border-line pt-4">
                    <div>
                      <p className="text-sm font-semibold text-fg">{review.name}</p>
                      <p className="text-xs text-muted">
                        {review.city} · {review.date}
                      </p>
                    </div>
                    <StarRating value={review.rating} size={13} showNumber={false} />
                  </figcaption>
                </figure>
              </ScrollReveal>
            ))}
          </div>
        </div>
      </section>

      {/* ---------------- CTA banner ---------------- */}
      <section className="shell py-24 sm:py-28">
        <ScrollReveal>
          <div className="cta-banner p-10 text-center sm:p-16">
            <FloatingGarnish variant="hero" className="opacity-60" />
            <p className="section-kicker text-accent">Come hungry</p>
            <h2 className="mt-3 font-display text-4xl leading-tight text-ivory sm:text-5xl">
              Visit the Aminabad counter
            </h2>
            <p className="mx-auto mt-4 max-w-md text-base leading-relaxed text-white/70">
              No reservations, no fuss — walk in, or send your order ahead on WhatsApp
              and it will be waiting.
            </p>
            <div className="mt-8 flex flex-wrap justify-center gap-3">
              <a
                href={BRANCH.mapsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="btn-solid"
              >
                <MapPin size={15} /> Get directions
              </a>
              <a
                href={`https://wa.me/${BRANCH.whatsapp}`}
                target="_blank"
                rel="noopener noreferrer"
                className="btn text-fg border border-white/25 hover:border-accent hover:text-accent"
              >
                Order on WhatsApp
              </a>
            </div>
            <p className="mt-6 inline-flex items-center gap-2 text-xs text-white/50">
              <Clock size={13} /> {BRANCH.hours}
            </p>
          </div>
        </ScrollReveal>
      </section>

      {/* ---------------- Location strip ---------------- */}
      <section className="shell pb-24">
        <ScrollReveal className="grid gap-6 lg:grid-cols-3">
          {SEATING.map((detail) => (
            <article key={detail.title} className="card-surface p-6">
              <h3 className="text-base font-semibold text-fg">{detail.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted">{detail.detail}</p>
            </article>
          ))}
        </ScrollReveal>
      </section>
    </>
  );
}
