'use client';

import { createContext, useCallback, useContext, useMemo, useState } from 'react';
import { ThemeProvider } from 'next-themes';
import { PACKAGING_PER_ITEM, TAX_RATE } from '@/lib/site';

const CartContext = createContext(null);

export function useCart() {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart must be used inside <Providers>.');
  }
  return context;
}

function lineKey(id, portion) {
  return `${id}__${portion}`;
}

function CartProvider({ children }) {
  const [lines, setLines] = useState([]);
  const [isOpen, setIsOpen] = useState(false);

  const openCart = useCallback(() => setIsOpen(true), []);
  const closeCart = useCallback(() => setIsOpen(false), []);

  const addItem = useCallback((item, portion = 'full', quantity = 1) => {
    const key = lineKey(item.id, portion);
    const price = portion === 'half' ? item.half : item.full;

    setLines((current) => {
      const existing = current.find((line) => line.key === key);
      if (existing) {
        return current.map((line) =>
          line.key === key
            ? { ...line, quantity: Math.min(line.quantity + quantity, 30) }
            : line
        );
      }
      return [
        ...current,
        {
          key,
          id: item.id,
          name: item.name,
          local: item.local,
          portion,
          unit: item.unit,
          diet: item.diet,
          price,
          quantity,
        },
      ];
    });
    setIsOpen(true);
  }, []);

  const changeQuantity = useCallback((key, delta) => {
    setLines((current) =>
      current
        .map((line) =>
          line.key === key
            ? { ...line, quantity: Math.min(Math.max(line.quantity + delta, 0), 30) }
            : line
        )
        .filter((line) => line.quantity > 0)
    );
  }, []);

  const removeLine = useCallback((key) => {
    setLines((current) => current.filter((line) => line.key !== key));
  }, []);

  const clearCart = useCallback(() => setLines([]), []);

  const totals = useMemo(() => {
    const subtotal = lines.reduce((sum, line) => sum + line.price * line.quantity, 0);
    const packaging = lines.length * PACKAGING_PER_ITEM;
    const gst = Math.round((subtotal + packaging) * TAX_RATE);
    const grandTotal = subtotal + packaging + gst;
    const count = lines.reduce((sum, line) => sum + line.quantity, 0);
    return { subtotal, packaging, gst, grandTotal, count };
  }, [lines]);

  const value = useMemo(
    () => ({
      lines,
      totals,
      isOpen,
      openCart,
      closeCart,
      addItem,
      changeQuantity,
      removeLine,
      clearCart,
    }),
    [
      lines,
      totals,
      isOpen,
      openCart,
      closeCart,
      addItem,
      changeQuantity,
      removeLine,
      clearCart,
    ]
  );

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export default function Providers({ children }) {
  return (
    <ThemeProvider
      attribute="class"
      defaultTheme="dark"
      enableSystem
      disableTransitionOnChange={false}
    >
      <CartProvider>{children}</CartProvider>
    </ThemeProvider>
  );
}
